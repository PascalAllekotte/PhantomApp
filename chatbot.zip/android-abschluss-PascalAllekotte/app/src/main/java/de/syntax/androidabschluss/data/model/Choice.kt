package de.syntax.androidabschluss.data.model

data class Choice(
    val text: String
)