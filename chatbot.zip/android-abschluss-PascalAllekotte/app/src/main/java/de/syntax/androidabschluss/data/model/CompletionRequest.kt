package de.syntax.androidabschluss.data.model

data class CompletionRequest(
    val prompt: String,
    val max_tokens: Int
)
