package de.syntax.androidabschluss.data.model

data class CompletionResponse(
    val choices: List<Choice>
)
